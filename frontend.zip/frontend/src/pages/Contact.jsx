import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import logoImg from "../assets/logo.png";
import {
  MapPin,
  Phone,
  Mail,
  Send,
} from "lucide-react";
import "./Contact.css";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    alert("Pesan Anda telah terkirim!");
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="contact-page">
      {/* NAVBAR */}
      <Navbar />

      {/* HERO SECTION */}
      <section className="contact-hero">
        <div className="contact-hero__bg" />
        <div className="contact-hero__overlay" />
        <div className="contact-hero__content">
          <div className="contact-hero__breadcrumb">
            <Link to="/">Home</Link>
            <span className="separator">/</span>
            <span>Hubungi Kami</span>
          </div>
          <h1 className="contact-hero__title">Hubungi Kami</h1>
          <p className="contact-hero__subtitle">
            Kami siap membantu Anda. Hubungi kami untuk pertanyaan, kerjasama, atau informasi lebih lanjut.
          </p>
        </div>
      </section>

      {/* CONTACT CONTENT */}
      <section className="contact-content">
        <div className="contact-content__inner">
          {/* Contact Info Cards */}
          <div className="contact-info-grid">
            <div className="contact-info-card">
              <div className="contact-info-card__icon">
                <Phone size={28} />
              </div>
              <h3 className="contact-info-card__title">Telepon</h3>
              <p className="contact-info-card__text">(021) 1234 5678</p>
              <p className="contact-info-card__text">0807 100 1500</p>
            </div>

            <div className="contact-info-card">
              <div className="contact-info-card__icon">
                <Mail size={28} />
              </div>
              <h3 className="contact-info-card__title">Email</h3>
              <p className="contact-info-card__text">info@info.co.id</p>
              <p className="contact-info-card__text">support@info.co.id</p>
            </div>

            <div className="contact-info-card">
              <div className="contact-info-card__icon">
                <MapPin size={28} />
              </div>
              <h3 className="contact-info-card__title">Alamat</h3>
              <p className="contact-info-card__text">Jl. Contoh No. 123</p>
              <p className="contact-info-card__text">Jakarta, Indonesia</p>
            </div>
          </div>

          {/* Contact Form & Map */}
          <div className="contact-main">
            {/* Form */}
            <div className="contact-form-section">
              <h2 className="contact-form-section__title">Kirim Pesan</h2>
              <p className="contact-form-section__subtitle">
                Isi formulir di bawah ini dan kami akan segera merespon pesan Anda.
              </p>

              <form className="contact-form" onSubmit={handleSubmit}>
                <div className="contact-form__row">
                  <div className="contact-form__group">
                    <label htmlFor="name" className="contact-form__label">
                      Nama Lengkap
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="contact-form__input"
                      placeholder="Masukkan nama lengkap"
                      required
                    />
                  </div>

                  <div className="contact-form__group">
                    <label htmlFor="email" className="contact-form__label">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="contact-form__input"
                      placeholder="Masukkan email"
                      required
                    />
                  </div>
                </div>

                <div className="contact-form__group">
                  <label htmlFor="subject" className="contact-form__label">
                    Subjek
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="contact-form__input"
                    placeholder="Masukkan subjek pesan"
                    required
                  />
                </div>

                <div className="contact-form__group">
                  <label htmlFor="message" className="contact-form__label">
                    Pesan
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    className="contact-form__textarea"
                    placeholder="Tulis pesan Anda di sini..."
                    rows={6}
                    required
                  />
                </div>

                <button type="submit" className="contact-form__button">
                  <Send size={18} />
                  <span>Kirim Pesan</span>
                </button>
              </form>
            </div>

            {/* Map */}
            <div className="contact-map-section">
              <h2 className="contact-map-section__title">Lokasi Kami</h2>
              <div className="contact-map">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126920.24097831853!2d106.759478!3d-6.2297465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3e945e34b9d%3A0x5371bf0fdad786a2!2sJakarta%2C%20Special%20Capital%20Region%20of%20Jakarta!5e0!3m2!1sen!2sid!4v1650000000000!5m2!1sen!2sid"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Lokasi Info.co.id"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <Footer />
    </div>
  );
}
