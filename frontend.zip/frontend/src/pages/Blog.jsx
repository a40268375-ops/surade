import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import api from "../services/api";
import logoImg from "../assets/logo.png";
import { InlineSpinner } from "../components/LoadingScreen";
import {
  User,
  Calendar,
  Clock,
  ArrowRight,
  Search,
} from "lucide-react";
import "./Blog.css";
import { DEFAULT_AVATAR } from "../utils/constants";

export default function Blog() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [blogs, setBlogs] = useState([]);
  const [categories, setCategories] = useState([{ id: "all", label: "Semua" }]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchBlogs();
  }, []);

  const fetchBlogs = async () => {
    try {
      const res = await api.get("/blogs?status=published&all=true");
      const raw = res.data?.data || res.data || [];
      const data = Array.isArray(raw) ? raw : (raw?.data || []);
      setBlogs(data);

      if (data.length > 0) {
        const catNames = data.map(b => (typeof b.category === "object" ? b.category?.name : b.category)).filter(Boolean);
        const uniqueCats = Array.from(new Set(catNames));
        setCategories([
          { id: "all", label: "Semua" },
          ...uniqueCats.map(name => ({ id: name.toLowerCase(), label: name }))
        ]);
      }
    } catch (err) {
      console.error("Failed to fetch blogs:", err);
    } finally {
      setLoading(false);
    }
  };

  const getCategoryLabel = (catId) => {
    if (!catId) return "Umum";
    const cat = categories.find(c => c.id === catId.toLowerCase());
    return cat?.label || catId || "Umum";
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    return d.toLocaleDateString("id-ID", { year: "numeric", month: "long", day: "numeric" });
  };

  const getReadTime = (content) => {
    if (!content) return "1 min";
    const words = content.split(/\s+/).length;
    const min = Math.ceil(words / 200);
    return min + " min";
  };

const getStorageUrl = (path) => {
    if (!path) return "";
    if (path.startsWith("http")) return path;
    const baseUrl = import.meta.env.VITE_API_URL.replace(/\/api$/i, "");
    return `${baseUrl}/storage/${path}`;
  };

  const getThumbnailUrl = (blog) => {
    if (blog.thumbnail) {
      return getStorageUrl(blog.thumbnail);
    }
    return "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&h=500&fit=crop";
  };

  const getUserAvatar = (blog) => {
    if (blog?.user?.avatar) {
      return getStorageUrl(blog.user.avatar);
    }
    return DEFAULT_AVATAR;
  };

  const filteredPosts = blogs.filter((post) => {
    const cat = (post.blog_category || "").toLowerCase();
    const matchesCategory = activeCategory === "all" || cat === activeCategory;
    const title = (post.title || "").toLowerCase();
    const excerpt = (post.excerpt || "").toLowerCase();
    const search = searchQuery.toLowerCase();
    const matchesSearch = !search || title.includes(search) || excerpt.includes(search);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="blog-page">
      {/* ── NAVBAR ── */}
      <Navbar />

      {/* ── BLOG HERO ── */}
      <section className="blog-hero">
        <div className="blog-hero__bg" />
        <div className="blog-hero__overlay" />
        <div className="blog-hero__content">
          <div className="blog-hero__breadcrumb">
            <Link to="/">Home</Link>
            <span className="separator">/</span>
            <span>Blog</span>
          </div>
          <h1 className="blog-hero__title">Blog</h1>
          <p className="blog-hero__subtitle">Jelajahi Cerita dan Informasi Menarik Seputar Budaya Indonesia</p>
        </div>
      </section>

      {/* ── BLOG CONTENT ── */}
      <section className="blog-content">
        <div className="blog-content__inner">
          {/* Search & Filter */}
          <div className="blog-controls">
            <div className="blog-search">
              <Search size={18} className="blog-search__icon" />
              <input
                type="text"
                placeholder="Cari artikel..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="blog-search__input"
              />
            </div>
            <div className="blog-categories">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  className={`blog-category-btn${activeCategory === cat.id ? " active" : ""}`}
                  onClick={() => setActiveCategory(cat.id)}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Loading */}
          {loading && (
            <InlineSpinner text="Memuat artikel..." />
          )}

          {/* Blog Grid */}
          {!loading && (
            <div className="blog-grid">
              {filteredPosts.map((post) => (
                <article key={post.id} className="blog-card">
                  <div className="blog-card__img-wrap">
                    <img src={getThumbnailUrl(post)} alt={post.title} className="blog-card__img" loading="lazy" />
                    <span className="blog-card__category">{getCategoryLabel(post.blog_category)}</span>
                  </div>
                  <div className="blog-card__body">
                    <h2 className="blog-card__title">{post.title}</h2>
                    <p className="blog-card__excerpt">{post.excerpt || post.content?.substring(0, 150)}</p>
                    <div className="blog-card__meta">
                      <span className="blog-card__meta-item">
                        <User size={14} />
                        {post.user?.name || post.author || "Penulis"}
                      </span>
                      <span className="blog-card__meta-item">
                        <Calendar size={14} />
                        {formatDate(post.published_at || post.created_at)}
                      </span>
                      <span className="blog-card__meta-item">
                        <Clock size={14} />
                        {getReadTime(post.content || post.excerpt)}
                      </span>
                    </div>
                    <Link to={`/blog/${post.id}`} className="blog-card__link">
                      Baca Selengkapnya
                      <ArrowRight size={16} />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          )}

          {!loading && filteredPosts.length === 0 && (
            <div className="blog-empty">
              <p>Tidak ada artikel yang ditemukan.</p>
            </div>
          )}
        </div>
      </section>

      {/* ── FOOTER ── */}
      <Footer />
    </div>
  );
}
