import { useParams, Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";
import Navbar from "../components/Navbar";
import { getStorageUrl } from "../utils/constants";
import {
  MapPin,
  Building2,
  Users,
  Store,
  Coffee,
  Smartphone,
  Shirt,
  Wrench,
  Search,
  CheckCircle2,
  Star,
  Loader2,
  ArrowLeft,
} from "lucide-react";

// Fix default Leaflet icon for Vite
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

// Helper component to recenter Leaflet map when city changes
function RecenterMap({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center && Array.isArray(center) && center.length === 2) {
      map.setView(center, 12, { animate: true });
    }
  }, [center, map]);
  return null;
}

const getCategoryIcon = (iconName, label = "") => {
  const lower = (iconName || label || "").toLowerCase();
  if (lower.includes("coffee") || lower.includes("cafe") || lower.includes("kuliner") || lower.includes("restaurant")) {
    return <Coffee size={18} />;
  }
  if (lower.includes("smartphone") || lower.includes("elektronik") || lower.includes("gadget")) {
    return <Smartphone size={18} />;
  }
  if (lower.includes("shirt") || lower.includes("fashion") || lower.includes("pakaian")) {
    return <Shirt size={18} />;
  }
  if (lower.includes("wrench") || lower.includes("servis") || lower.includes("tukang") || lower.includes("jasa")) {
    return <Wrench size={18} />;
  }
  if (lower.includes("building") || lower.includes("fasilitas") || lower.includes("hotel")) {
    return <Building2 size={18} />;
  }
  return <Store size={18} />;
};

const CITY_COORDS = {
  surade: [-7.3444, 106.5866],
  sukabumi: [-6.9277, 106.9300],
  jakarta: [-6.2088, 106.8456],
  bogor: [-6.5971, 106.8060],
  bandung: [-6.9175, 107.6191],
  surabaya: [-7.2575, 112.7521],
  bali: [-8.4095, 115.1889],
  depok: [-6.4025, 106.7942],
  aceh: [5.5483, 95.3238],
};

const getCityCoords = (cityObj) => {
  if (cityObj?.lat && cityObj?.lng) return [parseFloat(cityObj.lat), parseFloat(cityObj.lng)];
  if (cityObj?.slug && CITY_COORDS[cityObj.slug.toLowerCase()]) return CITY_COORDS[cityObj.slug.toLowerCase()];
  if (cityObj?.name) {
    const key = Object.keys(CITY_COORDS).find((k) => cityObj.name.toLowerCase().includes(k));
    if (key) return CITY_COORDS[key];
  }
  return [-7.3444, 106.5866];
};

const getBusinessCoords = (b, fallbackCenter, index = 0) => {
  if (b.latitude && b.longitude) return [parseFloat(b.latitude), parseFloat(b.longitude)];
  if (b.lat && b.lng) return [parseFloat(b.lat), parseFloat(b.lng)];
  const offsetLat = ((index % 5) - 2) * 0.008;
  const offsetLng = ((Math.floor(index / 5) % 5) - 2) * 0.008;
  return [fallbackCenter[0] + offsetLat, fallbackCenter[1] + offsetLng];
};

const DEFAULT_CATEGORIES = [
  { id: "all", label: "Semua", icon: <Store size={18} /> },
  { id: "bisnis-market", label: "Bisnis & Market", icon: <Store size={18} /> },
  { id: "cafe-restaurant", label: "Cafe & Restaurant", icon: <Coffee size={18} /> },
  { id: "elektronik-gadget", label: "Elektronik & Gadget", icon: <Smartphone size={18} /> },
  { id: "fashion", label: "Fashion", icon: <Shirt size={18} /> },
  { id: "servis-tukang", label: "Servis & Tukang", icon: <Wrench size={18} /> },
];

export default function SmartCity() {
  const { id, slug } = useParams();
  const cityKey = id || slug || "surade";

  const [city, setCity] = useState(null);
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingBusinesses, setLoadingBusinesses] = useState(true);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [cityKey]);

  // Fetch Smart City by id/slug
  useEffect(() => {
    const fetchSmartCityData = async () => {
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL}/smart-cities`);
        if (!res.ok) throw new Error("Failed to fetch smart cities");
        const data = await res.json();
        const citiesData = data?.data || data || [];
        if (Array.isArray(citiesData)) {
          let current = citiesData.find(
            (c) =>
              String(c.id) === String(cityKey) ||
              c.slug === cityKey ||
              c.slug === String(cityKey).toLowerCase() ||
              c.name?.toLowerCase().includes(String(cityKey).toLowerCase())
          );

          if (!current) {
            const cityName = cityKey ? (cityKey.charAt(0).toUpperCase() + cityKey.slice(1).replace(/-/g, " ")) : "Kelurahan Surade";
            current = {
              id: cityKey || "surade",
              slug: cityKey || "surade",
              name: cityName.includes("Surade") ? "Kelurahan Surade" : cityName,
              type: "smart_city",
              description:
                "Kelurahan Surade adalah pusat pemerintahan Kecamatan Surade sekaligus pusat aktivitas warga, ditandai dengan Bunderan/Tugu Surade. Program Smart Village di sini fokus pada digitalisasi layanan publik dan pusat perdagangan kecamatan.",
              image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1600&h=900&fit=crop",
              img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1600&h=900&fit=crop",
              population: "9.562 Jiwa",
              area: "Pusat Kec. Surade",
              bisnis: 96,
            };
          }
          setCity(current);
        }
      } catch (err) {
        console.error("Error fetching smart cities:", err);
        setCity({
          id: cityKey || "surade",
          slug: cityKey || "surade",
          name: "Kelurahan Surade",
          type: "smart_city",
          description:
            "Kelurahan Surade adalah pusat pemerintahan Kecamatan Surade sekaligus pusat aktivitas warga, ditandai dengan Bunderan/Tugu Surade. Program Smart Village di sini fokus pada digitalisasi layanan publik dan pusat perdagangan kecamatan.",
          image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1600&h=900&fit=crop",
          img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1600&h=900&fit=crop",
          population: "9.562 Jiwa",
          area: "Pusat Kec. Surade",
          bisnis: 96,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchSmartCityData();
  }, [cityKey]);

  // Fetch Categories from API or fallback
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL}/categories`);
        const data = await res.json();
        const list = Array.isArray(data) ? data : (data?.data || []);
        if (Array.isArray(list) && list.length > 0) {
          const mapped = [
            { id: "all", label: "Semua", icon: <Store size={18} /> },
            ...list.map((c) => ({
              id: c.slug || String(c.id),
              label: c.name,
              icon: getCategoryIcon(c.icon, c.name),
            })),
          ];
          setCategories(mapped);
        }
      } catch (err) {
        console.error("Error fetching categories:", err);
      }
    };
    fetchCategories();
  }, []);

  // Fetch businesses for the current city
  useEffect(() => {
    if (!city) return;
    const fetchCityBusinesses = async () => {
      setLoadingBusinesses(true);
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL}/businesses?location=${city.slug}&all=true`);
        const data = await res.json();
        const list = Array.isArray(data) ? data : (data?.data || []);
        setBusinesses(list);
      } catch (err) {
        console.error("Error fetching city businesses:", err);
        setBusinesses([]);
      } finally {
        setLoadingBusinesses(false);
      }
    };

    fetchCityBusinesses();
  }, [city]);

  const filteredBusinesses = businesses.filter((b) => {
    const categoryName = (b.category?.name || b.category || "").toLowerCase();
    const matchesCategory = selectedCategory === "all" || categoryName.includes(selectedCategory.toLowerCase());

    const matchesSearch = !searchQuery ||
      (b.name || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.description || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (b.city || "").toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  const cityCenterCoords = getCityCoords(city);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col font-sans">
        <Navbar />
        <div className="flex-1 flex flex-col items-center justify-center gap-3 p-8">
          <Loader2 className="w-10 h-10 text-[#00b074] animate-spin" />
          <p className="text-slate-600 font-medium text-sm">Memuat Data Smart City...</p>
        </div>
      </div>
    );
  }

  if (!city) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col font-sans">
        <Navbar />
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8 max-w-md mx-auto">
          <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mb-4">
            <Building2 size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Kota Tidak Ditemukan</h2>
          <p className="text-slate-500 text-sm mb-6">Kota yang Anda cari tidak tersedia dalam program Smart City &amp; Village.</p>
          <Link to="/" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#00b074] text-white text-sm font-semibold hover:bg-[#009663] transition-colors">
            <ArrowLeft size={16} /> Kembali ke Beranda
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 font-sans">
      <Navbar />

      {/* ── HERO BANNER ── */}
      <section className="relative min-h-[520px] md:min-h-[560px] flex flex-col justify-center overflow-hidden">
        {/* Background Image: Aerial Island surrounded by deep ocean */}
        <img
          src={city.image || city.img || "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1600&h=900&fit=crop"}
          alt={city.name}
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        {/* Vignette Overlay */}
        <div className="absolute inset-0 bg-slate-950/50" />

        {/* Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-28 pb-12 flex flex-col items-center text-center">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-xs sm:text-sm text-white/90 font-normal mb-5 flex-wrap justify-center">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <span className="text-white/70">&rarr;</span>
            <span className="text-white/90">Smart City</span>
            <span className="text-white/70">&rarr;</span>
            <span className="text-white font-medium">{city.name}</span>
          </nav>

          {/* Title: [Nama Kota] Smart City */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mb-4 leading-tight">
            {city.name}{" "}
            <span className="text-[#3b82f6]">
              {city.type === "smart_village" ? "Smart Village" : "Smart City"}
            </span>
          </h1>

          {/* Subtitle Description */}
          <p className="max-w-3xl text-xs sm:text-sm md:text-[15px] text-white/90 leading-relaxed mb-8 font-normal">
            {city.description ||
              "Kelurahan Surade adalah pusat pemerintahan Kecamatan Surade sekaligus pusat aktivitas warga, ditandai dengan Bunderan/Tugu Surade. Program Smart Village di sini fokus pada digitalisasi layanan publik dan pusat perdagangan kecamatan."}
          </p>

          {/* 3 Statistic Cards */}
          <div className="flex flex-wrap items-center justify-center gap-4 w-full max-w-4xl mx-auto">
            {/* Card 1: Bisnis Terdaftar */}
            <div className="bg-[#0f1f2e]/75 backdrop-blur-md border border-white/10 rounded-2xl px-6 py-4 flex items-center gap-4 text-left shadow-xl min-w-[210px] flex-1 max-w-[280px]">
              <div className="text-[#00c48c] shrink-0">
                <Store size={26} strokeWidth={1.8} />
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-bold text-white leading-tight">
                  {businesses.length > 0 ? businesses.length : (city.bisnis || 96)}
                </div>
                <div className="text-xs text-slate-300 font-normal mt-0.5">Bisnis Terdaftar</div>
              </div>
            </div>

            {/* Card 2: Penduduk */}
            <div className="bg-[#0f1f2e]/75 backdrop-blur-md border border-white/10 rounded-2xl px-6 py-4 flex items-center gap-4 text-left shadow-xl min-w-[210px] flex-1 max-w-[280px]">
              <div className="text-[#00c48c] shrink-0">
                <Users size={26} strokeWidth={1.8} />
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-bold text-white leading-tight">
                  {city.population || "9.562 Jiwa"}
                </div>
                <div className="text-xs text-slate-300 font-normal mt-0.5">Penduduk</div>
              </div>
            </div>

            {/* Card 3: Luas Wilayah */}
            <div className="bg-[#0f1f2e]/75 backdrop-blur-md border border-white/10 rounded-2xl px-6 py-4 flex items-center gap-4 text-left shadow-xl min-w-[210px] flex-1 max-w-[280px]">
              <div className="text-[#00c48c] shrink-0">
                <MapPin size={26} strokeWidth={1.8} />
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-bold text-white leading-tight truncate">
                  {city.area || `Pusat Kec. ${city.name?.replace(/^(Kelurahan|Desa|Kota)\s*/i, "") || "Surade"}`}
                </div>
                <div className="text-xs text-slate-300 font-normal mt-0.5">Luas Wilayah</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CATEGORY FILTER BAR ── */}
      <section className="bg-white border-b border-slate-100 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 overflow-x-auto whitespace-nowrap pb-2 scrollbar-none [&::-webkit-scrollbar]:hidden">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat.id;

              const renderLabel = () => {
                if (cat.label === "Semua") return <span>Semua</span>;
                if (cat.label.includes(" & ")) {
                  const parts = cat.label.split(" & ");
                  return (
                    <div className="flex flex-col text-left leading-tight">
                      <span>{parts[0]} &amp;</span>
                      <span>{parts[1]}</span>
                    </div>
                  );
                }
                const words = cat.label.split(" ");
                if (words.length === 2) {
                  return (
                    <div className="flex flex-col text-left leading-tight">
                      <span>{words[0]}</span>
                      <span>{words[1]}</span>
                    </div>
                  );
                }
                return <span>{cat.label}</span>;
              };

              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`shrink-0 flex items-center gap-3 px-6 py-3.5 rounded-2xl text-xs font-semibold transition-all duration-200 cursor-pointer shadow-sm ${
                    isActive
                      ? "bg-[#00b074] text-white font-bold text-sm"
                      : "bg-white border border-slate-200/90 text-slate-700 hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  <span className={isActive ? "text-white" : "text-slate-500"}>
                    {cat.icon}
                  </span>
                  {renderLabel()}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── MAIN BUSINESS DIRECTORY & MAP SECTION ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        {/* Section Title */}
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mb-8">
          Bisnis di {city.name}{" "}
          <span className="text-slate-400 font-normal">
            ({filteredBusinesses.length})
          </span>
        </h2>

        {/* 2-Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-8 items-start">
          {/* Left Column: Empty State or Business Cards */}
          <div>
            {loadingBusinesses ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {[1, 2, 3, 4].map((n) => (
                  <div key={n} className="bg-white border border-slate-200 rounded-2xl p-4 animate-pulse h-64 flex flex-col justify-between">
                    <div className="h-32 bg-slate-200 rounded-xl mb-3" />
                    <div className="h-4 bg-slate-200 rounded w-3/4 mb-2" />
                    <div className="h-3 bg-slate-100 rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : filteredBusinesses.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {filteredBusinesses.map((b, index) => {
                  const imgUrl = getStorageUrl(b.logo || b.banner) || "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=600&h=400&fit=crop";
                  const categoryName = typeof b.category === "object" ? b.category?.name : (b.category || "Umum");
                  const rating = b.rating || b.average_rating || 5.0;

                  return (
                    <Link
                      key={b.id || index}
                      to={`/business/${b.id}`}
                      className="group bg-white border border-slate-200/80 hover:border-[#00b074]/40 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-200 flex flex-col"
                    >
                      {/* Image Cover */}
                      <div className="relative h-44 w-full overflow-hidden bg-slate-100">
                        <img
                          src={imgUrl}
                          alt={b.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          loading="lazy"
                        />
                        <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#00b074] text-white">
                          Buka
                        </span>
                        {b.is_verified && (
                          <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-700 text-white flex items-center gap-1">
                            <CheckCircle2 size={12} /> Terverifikasi
                          </span>
                        )}
                      </div>

                      {/* Card Body */}
                      <div className="p-5 flex flex-col flex-1">
                        <span className="text-xs font-semibold text-[#00b074] uppercase tracking-wider mb-1">
                          {categoryName}
                        </span>
                        <h4 className="text-base font-bold text-slate-900 group-hover:text-[#00b074] transition-colors line-clamp-1 mb-1.5">
                          {b.name}
                        </h4>
                        <p className="text-xs text-slate-500 line-clamp-2 mb-4 leading-relaxed">
                          {b.description || "Informasi bisnis resmi terdaftar di direktori Smart City."}
                        </p>

                        <div className="mt-auto pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                          <span className="flex items-center gap-1 truncate max-w-[160px]">
                            <MapPin size={13} className="text-[#00b074]" />
                            <span className="truncate">{b.city || city.name}</span>
                          </span>
                          <span className="flex items-center gap-1 font-semibold text-amber-500">
                            <Star size={13} fill="currentColor" />
                            <span>{rating}</span>
                          </span>
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            ) : (
              /* Empty State matching Screenshot 2 */
              <div className="bg-white border border-slate-200/80 rounded-2xl p-16 text-center shadow-sm flex flex-col items-center justify-center min-h-[380px]">
                <Search size={48} className="text-slate-300 stroke-[1.5] mb-4" />
                <h3 className="text-xl font-bold text-slate-900 mb-2">Tidak ada bisnis ditemukan</h3>
                <p className="text-sm text-slate-500 max-w-sm">
                  Coba ubah kata kunci pencarian atau filter kategori
                </p>
              </div>
            )}
          </div>

          {/* Right Column: Leaflet Map */}
          <div className="sticky top-24 w-full h-[480px] lg:h-[520px] rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-slate-100">
            <MapContainer
              center={cityCenterCoords}
              zoom={12}
              style={{ height: "100%", width: "100%" }}
              scrollWheelZoom={true}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <RecenterMap center={cityCenterCoords} />
              {filteredBusinesses.map((b, idx) => {
                const pos = getBusinessCoords(b, cityCenterCoords, idx);
                return (
                  <Marker key={b.id || idx} position={pos}>
                    <Popup>
                      <div className="p-1 text-slate-800">
                        <strong className="text-sm font-bold block mb-1">{b.name}</strong>
                        <p className="text-xs text-slate-500 mb-2">{b.city || city.name}</p>
                        <Link
                          to={`/business/${b.id}`}
                          className="inline-block text-xs font-semibold text-[#00b074] hover:underline"
                        >
                          Lihat Detail &rarr;
                        </Link>
                      </div>
                    </Popup>
                  </Marker>
                );
              })}
            </MapContainer>
          </div>
        </div>
      </section>
    </div>
  );
}
